This is our prototype for our rhythm based boxing game, featuring five levels with five different songs.
- All five songs are currently loaded and playable by selecting the corresponding level from the select screen
- Beats will spawn in one of four lanes, which are A, S, D, F from left to right
- Hitting the key at the right time will give you points based on how close the beat was to the line
- A combo counter in the corner indicates how many beats you've hit in a row
- The game will end once you get 10 misses without hitting a note in a while, or if the player reaches the end of the song

Beta Changelog:
- There's now more screens! We've added a title screen, level select screen, and game over screen, with navigation between them
- The level select screen allows you to preview the song for each level by hovering over the button
- Beats now spawn based on the notes in the song
- Some visuals have been added, with fun spirals on the title screen and a set in the gameplay screen that
  changes color based on how many notes the player has missed

Final Changelog:

Many changes!
- Complete UI design and layout overhaul!
    - Perlin noise background added to all screens, changing based on screen or level
    - Buttons are now rounded and reorganized
    - New font has been added
    - Title screen has new set pieces! Spinny things! They spin
    - Level select screen has been re-ordered, now diplays the enemy that appears in each level
    - Gameplay screen has much more information!
        - Health is displayed in the top left corner, as an audio visualizer
        - Combo meter has been added, and a combo count also resides within the audio visualizer
        - Characters have been added to gameplay screen! They bounce! And punch each other
        - Lanes are now marked with boxes with the correct keyes
        - Score moved and made more clear
- Added easy mode, preventing game over from too many misses
- Added credits screen
- Re-did beat generation to make it more accurate to each song
- Each lane of beats now has its own color
- Added score multiplier that's tied to the combo counter




